Zemberek-NLP Distributions
==========================

Here you can find separate jar files of Zemberek-NLP library modules and their dependencies.

zemberek-core : guava

zemberek-morphology : zemberek-core, zemberek-lm, zemberek-tokenization, guava, berkeleylm, antlr4-runtime

zemberek-hyphenation : zemberek-core, guava

zemberek-tokenization : zemberek-core, guava, antlr4-runtime

zemberek-lm : zemberek-core, guava
